# d3-barcodetree

YOUR DESCRIPTION HERE. Replace all instances of `barcodetree` in this file with the name of your new plugin.

## Installing

If you use NPM, `npm install d3-barcodetree`. Otherwise, download the [latest release](https://github.com/d3/d3-barcodetree/releases/latest).

## API Reference

YOUR API DOCUMENTATION HERE. Use bold for symbols (such as constructor and method names) and italics for instances. See the other D3 modules for examples.

<a href="#barcodetree" name="barcodetree">#</a> <b>barcodetree</b>()

Computes the answer to the ultimate question of life, the universe, and everything.
